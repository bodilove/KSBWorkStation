﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace StartUp.Enity
{
    public class UsersEnity
    {
        public int ID { get; set; }

        public string Name { get; set; }

        public string Type { get; set; }

        public string Number { get; set; }

        public string Password { get; set; }

        public string Description { get; set; }

    }
}
